first_name="Toma"
counter01=100
miles=1000.0

#Variable Naming Rules
    #1. [A-Z a-z 0-9 _ = 63]
    #2. can't start variavle name with number
# Variable Standard
    #a. variable name should be used all small latter
    #b. meningfull name with naming standaed (Underscoring)

print(first_name)
print(counter01)
print(miles)
print(type(first_name))
print(type(counter01))
print(type(miles))
#id(name)
x=bytes(4)
print(x)



