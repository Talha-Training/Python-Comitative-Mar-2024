# list=['abcd',676,7.8,'kobir',9.09]
# print(list)
# print(list[2:])
# print(list * 2)


input_str=input("Enter elements of the list separated by space: ")
my_list=list(int,input_str.split())

print("My List: ",my_list)