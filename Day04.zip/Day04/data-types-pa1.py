# x=str(10)
# y=int(10)
# z=float(10)
# # print(type(x))

# print("x=",x)
# print("y=",y)
# print("z=",z)
# # print

# a=b=c=10

# print("a=",a)
# print("b=",b)
# print("c=",c)

a,b,c,name=10,20,30,'Saahil'

print("a=",a)
print("b=",b)
print("c=",c)
print("Name=",name)










