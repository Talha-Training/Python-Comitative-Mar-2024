# var1=1000
# var2=10.3987
# var3=10+3J

# print(type(var1))

str = 'Hello World!'

print(str)
print(str[0])
# print(str[3:])
print(str * 2)
print(str + " test") #concatanation

