
def my_function():
    print("Hello from my Function")


# my_function()
