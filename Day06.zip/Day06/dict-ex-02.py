list1=[10,30,54,21]
tup=(43,54,12,87)
dict={'Name': 'Toma','Age':20,'Class':13}
dict['Age']=20
dict['University']='IUT'
# del dict['Name']
# dict.clear()
# del dict
print(dict['Age'])
