# tup1=("Toma","Saahil","Shafana",90,91,99)
# tup2=(54,76,87,34,23,21)


# print(tup1 * 2)

# tup2[0]=100
# print(tup2)
# mylist=list(tup2)

# mylist.sort()
# print(mylist)

# tup2=tuple(mylist)
# print(tup2)

# a,b,c,d,e,f=tup2

# print('a:',a,'b:',b,'c:',c)


# indices=range(len(tup2))
# # print(list1)
# for a in indices:
#     print("list1[{}]:".format(a),tup2[a])
    
# for a in range(5):
#     # print("list1[{}]:".format(a),tup2[a])
#     print(a)
    
tup2=(54,76,87,34,23,21,87,90,87)

a=tup2.index(34)
print(a)




    