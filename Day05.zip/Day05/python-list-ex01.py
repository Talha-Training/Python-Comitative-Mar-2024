# list1=[12,34,56,78,54,23]
# list2=[2.4,"ABC",89,True,"Dhaka"]

# print(list1[5])
# print(12 in list1)
# print(list1[4] + list2[2])
# print(list1[-2])
# print(list1[1:])


# list1=["a","b","c","d","e"]
# list2=["X","Y","Z"]
# list1[1:4]=list2
# print(list1)

# list1[5]=100;
# print(list1)

# list2.append("K")
# list2.insert(1,"C")
list1=["a","b","c","d","e"]
# list2=["X","Y","Z"]

# list1.remove("c")
# list1.pop(1)
# del list1[1:3]
indices=range(len(list1))
# print(list1)
for a in indices:
    print("list1[{}]:".format(a),list1[a])







