students={
    "Toma":85,
    "Saahil":91,
    "Shafana":82
}

def update_score(student_name,new_score):
    if student_name in students:
        students[student_name]=new_score
        print(f"Score Updated for {student_name} to {new_score}")
    else:
        print(f" {student_name} not found in the student list")




student_name= input("Enter the student's name: ")
new_score= int(input("Enter the new score: "))

update_score(student_name,new_score)

print("Updated Student List: ")
for name,score in students.items():
    print(f"{name}: {score}")




# print("")
