

# def new_tri(line_number):
#     x = 1
#     while x<=line_number:
#         print('*' * x)
#         x = x + 1




# line_number=int(input("Enter Line Number : "))

# new_tri(line_number)
