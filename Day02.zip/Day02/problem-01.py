my_string="FahimH"
count=sum(1 for char in my_string if char.isupper())
#print(count)

if(count >= 2):
    print("TRUE")
else:
    print("FALSE")




