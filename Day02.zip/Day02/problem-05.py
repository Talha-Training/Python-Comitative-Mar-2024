my_list=[1,2,3]

for i in range(len(my_list)):
    for j in range(i+1, len(my_list)):
        product=my_list[i]*my_list[j]
if product%2 == 0:
    print("TRUE")
else:
    print("FALSE")
        
    

