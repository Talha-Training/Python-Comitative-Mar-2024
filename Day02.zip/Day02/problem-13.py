input_n=3
output=0
for i in range(1,input_n):
    output += i * (i+1)
print(output)

