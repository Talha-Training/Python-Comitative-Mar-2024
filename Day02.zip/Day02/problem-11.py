input_numbers=145089

all_digits=set(map(int, "0123456789"))
given_digits=set(map(int,str(input_numbers)))
missing_digits=sorted(all_digits-given_digits)

print(missing_digits)
