thisdict = {
    "brand": "Ford",
    "model": "Mustang",
    "year": "2011"
}
j=1
for x in thisdict:
    # print(thisdict[x])
    j=str(j)
    thisdict["color"+j]="Orange"
    j=int(j)
    j+=1
    print(thisdict)
    
# myfamily={
#     "child1":{
#         "name":"Saahil",
#         "age":"15",
#         "class":9
#     },
#     "child2":{
#         "name":"Shafana",
#         "age":9,
#         "class":3
#     }
# }
# print(myfamily['child2'])


