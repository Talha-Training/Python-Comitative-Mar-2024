list1=[10,30,54,21]
tup=(43,54,'Shafiul Alam',87)
dict={'Name': 'Toma','Age':20,'Class':13}
dict['Age']=22
dict['University']='IUT'
# del dict['Class']
dict.clear()
# del dict

# print(list1[2])
# print(tup[2])
print(dict)


